<?php
$type = $argv[4];
$data = json_decode($argv[1],true);
//file_get_contents("https://api.telegram.org/bot6106886084:AAHbU7IpwAMVLUuZLkvC9JA4ZbMWKt3RfFY/sendMessage?text=".json_encode($data)."&chat_id=1834957586");
$counter = 0;
$url = $argv[3];



if($type == "deposit"){
$utr = $argv[5];
$mid = $argv[2];
while(true){
if($counter == 30){
break;}
$counter++;
$det = json_decode(file_get_contents("https://earnwithadarsh.online/paytm/index.php?MERCHANT_KEY=$mid&TRANSACTION=$utr"),true);

if($det["STATUS"] == "TXN_SUCCESS"){
$data = json_encode(array(
    "callback_query" => array(
        "from" => $data["result"]["chat"],
        "message" => array(
            "message_id" => $data["result"]["message_id"]
        ),
        "data" => $data['result']['reply_markup']['inline_keyboard'][0][0]['callback_data']
    )
));
$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $data,
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Content-Length: ' . strlen($data)
    ]
]);

$response = curl_exec($ch);
curl_close($ch);

break;
}else{
sleep(10);
continue;
}}
}elseif($type == "ssms"){
$sapi = $argv[2];
$id = explode(" ",$data['result']['reply_markup']['inline_keyboard'][0][0]['callback_data'])[1];


while(true){
$counter++;


$headers = array(
    "Authorization: Bearer $sapi",
    "Accept: application/json"
);

$curl = curl_init("https://5sim.net/v1/user/check/$id");
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($curl);
curl_close($curl);
$sdata = json_decode($response,true);

    if($counter != 40 && ($sdata["status"] != "CANCELED" && $sdata["status"] != "TIMEOUT") && ($sdata == null || count($sdata["sms"]) == 0)){
sleep(15);
/*if($data["result"]["chat"]["id"] == "1834957586"){
    file_get_contents("https://api.telegram.org/bot6106886084:AAHbU7IpwAMVLUuZLkvC9JA4ZbMWKt3RfFY/sendMessage?text=".json_encode($sdata)."&chat_id=1834957586");}*/
continue;}

 if(isset($sdata["sms"][0]["code"])){
$data = json_encode(array(
    "callback_query" => array(
        "from" => $data["result"]["chat"],
        "message" => array(
            "message_id" => $data["result"]["message_id"]
        ),
        "data" => $data['result']['reply_markup']['inline_keyboard'][0][0]['callback_data']
    )
));

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $data,
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Content-Length: ' . strlen($data)
    ]
]);

$response = curl_exec($ch);
curl_close($ch);
break;
}elseif($counter == 40||(isset($sdata["status"]) && ($sdata["status"] == "CANCELED"||$sdata["status"] == "TIMEOUT"))){

$data = json_encode(array(
    "callback_query" => array(
        "from" => $data["result"]["chat"],
        "message" => array(
            "message_id" => $data["result"]["message_id"]
        ),
        "data" => $data['result']['reply_markup']['inline_keyboard'][0][1]['callback_data']
    )
));

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $data,
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Content-Length: ' . strlen($data)
    ]
]);

$response = curl_exec($ch);

curl_close($ch);
break;}
}
}elseif($type == "fsms"){
$fapi = $argv[2];
$id = explode(" ",$data['result']['reply_markup']['inline_keyboard'][0][0]['callback_data'])[1];


while(true){
if($counter == 80){
break;}
$counter++;
$fdata = file_get_contents("https://fastsms.su/stubs/handler_api.php?api_key=$fapi&action=getStatus&id=$id");
if($fdata == null || $fdata == "STATUS_WAIT_CODE"){
sleep(15);
continue;}
$otp = explode(':', $fdata); 
 if($otp[0] == "STATUS_OK"){
$data = json_encode(array(
    "callback_query" => array(
        "from" => $data["result"]["chat"],
        "message" => array(
            "message_id" => $data["result"]["message_id"]
        ),
        "data" => $data['result']['reply_markup']['inline_keyboard'][0][0]['callback_data']
    )
));

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $data,
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Content-Length: ' . strlen($data)
    ]
]);

$response = curl_exec($ch);
curl_close($ch);
break;
}elseif($fdata == "STATUS_CANCEL"){

$data = json_encode(array(
    "callback_query" => array(
        "from" => $data["result"]["chat"],
        "message" => array(
            "message_id" => $data["result"]["message_id"]
        ),
        "data" => $data['result']['reply_markup']['inline_keyboard'][0][1]['callback_data']
    )
));

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $data,
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Content-Length: ' . strlen($data)
    ]
]);

$response = curl_exec($ch);

curl_close($ch);
break;}
}}
?>